# 📊 Power BI Report

## 📌 Project Description

A Power BI dashboard created to visualize dataset metrics, analyze key trends, and generate data insights.

---

## 🔑 Features

* **Interactive Filters:** Dynamic slicers by date, category, and region.
* **KPI Metrics:** Summaries for total sales, counts, and performance.
* **Custom Calculations:** DAX measures for totals and time-based calculations.

---

## 🛠️ Tools Used

* **Power BI Desktop:** Report creation and visual presentation.
* **Power Query:** Data cleaning and transformations.
* **DAX:** Analytical calculations.

---

## 🚀 Usage Instructions

1. Download the `.pbix` file from this repository.
2. Open the file in **Power BI Desktop**.
3. Use the slicers to filter data.

---

## 👤 Author

* **Name:** Mostafa Mohamed Eltaweel
* **Role:** Data Analyst
